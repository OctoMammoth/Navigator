package com.ludumdevo.navigator;
public final class D {
  public static final String  SERVER_URL    = "https://api.navigine.com";
  public static final String  USER_HASH     = "0000-0000-0000-0000";
  public static final String  LOCATION_NAME = "Navigine Demo";
  public static final boolean WRITE_LOGS    = false;
}
